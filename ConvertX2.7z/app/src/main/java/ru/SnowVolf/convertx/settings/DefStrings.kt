package ru.SnowVolf.convertx.settings

/**
 * Created by Snow Volf on 18.02.2017, 6:50
 */

object DefStrings {
    var TAG = "ConvertX"
    var GIRL = "JavaGirl"
}
