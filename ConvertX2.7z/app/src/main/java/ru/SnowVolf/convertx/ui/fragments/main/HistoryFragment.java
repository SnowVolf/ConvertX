package ru.SnowVolf.convertx.ui.fragments.main;

import ru.SnowVolf.convertx.ui.fragments.base.BaseFragment;

/**
 * Created by Snow Volf on 21.06.2017, 8:12
 */

public class HistoryFragment extends BaseFragment {

}
